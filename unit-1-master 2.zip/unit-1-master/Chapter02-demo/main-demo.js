// Add all scripts to the JS folder
function cities(){

    var madison = {
        name: "Madison",
        county: "Dane",
        population: 250000
    }



    document.getElementById('mydiv').innerHTML = madison.name;

     var cityList = [{
        name: 'Madison'
    },
    {
        name: 'Milwaukee'
    },
    {
        name: 'Green Bay'
    },
    {
        name: 'Superior'
    }];

    var header = document.createElement("h1");
        header.innerHTML = cityList[0].name;

    document.getElementById('mydiv').appendChild(header);

// how is "city" something random? because we never mentioned "city", we only said cityList and cities. Are we declaring city as a another function?

    cityList.forEach(function(city){
        var item = document.createElement("h2");
        item.innerHTML = city.name;
// what does .innerHTML do and .name do?
        document.getElementById('mydiv').appendChild(item);

        if (city.name == 'Green Bay'){
            item.style.color = 'green';
        }

        if (city.name == 'Madison'){
            item.addEventListener('mouseenter', function(){
                item.style.color = 'green';
            })
            item.addEventListener('mouseleave', function(){
                item.style.color = 'black';
            })
        }
    })
    
}
window.onload = cities();
